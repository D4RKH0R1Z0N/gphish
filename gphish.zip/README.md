<h1 align="center">
  G-Phish
</h1>

<h5 align="center">
  ⚠💀 Warning! This project is only made for Educational purposes, I am not responsible for any of you actions! 💀⚠
</h5>

<p align="center">
  <img alt="GitHub repo size" src="https://img.shields.io/github/repo-size/D4RKH0R1Z0N/gphish?style=for-the-badge">
  <img alt="author" src="https://img.shields.io/badge/Made%20by-D4RKH0R1Z0N-blue?style=for-the-badge">
</p>

<h4 align="center">
  Status: ✔️ Available
  <br>
  MAKE THE IMPOSSIBLE POSSIBLE!
</h4>

<div align="center">
  <h2>Deploy</h2>
  <a href="https://heroku.com/deploy?template=https://github.com/D4RKH0R1Z0N/gphish">
    <img src="https://www.herokucdn.com/deploy/button.svg" alt="Deploy">
  </a>
</div>
  <br>
 <br>
 
| Demo | Demo |
| ------------  | ------------ |
|![](https://gphish.herokuapp.com/images/demo1.png)|![](https://gphish.herokuapp.com/images/demo2.png)
| Demo | Demo |
|![](https://gphish.herokuapp.com/images/demo3.png)|![](https://gphish.herokuapp.com/images/demo5.png)
  
<div align="center">
  <h2>Written in</h2>
  <img src="https://img.shields.io/badge/Css3-05122A?style=for-the-badge&logo=css3" alt="css3 Badge" height="25">&nbsp;
  <img src="https://img.shields.io/badge/Html5-05122A?style=for-the-badge&logo=html5" alt="html5 Badge" height="25">&nbsp;
  <img src="https://img.shields.io/badge/Javascript-05122A?style=for-the-badge&logo=javascript" alt="javascript Badge" height="25">&nbsp;
  <img src="https://img.shields.io/badge/PHP-05122A?style=for-the-badge&logo=php" alt="PHP Badge" height="25">&nbsp;
</div>

<h5 align="center">
  ⚠💀 Warning! This project is only made for Educational purposes, I am not responsible for any of you actions! 💀⚠
</h5>